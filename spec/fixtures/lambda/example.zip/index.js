exports.handler = (event, context) => {

    console.log("Hello!");
    context.done();

}
